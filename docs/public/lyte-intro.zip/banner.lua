-- Renders a big "Lyte2D" banner in the center of the screen. Waves, color cycles,
-- and responds to the mouse as well -- very exciting.

local Color = require("color")

local BANNER = {
    "   #####              ####             ######  #########   ",
    "    ###                ##             ###  ###  ###   ###  ",
    "    ###     #### ### ######   ######       ###  ###    ### ",
    "    ###      ##  ##    ##    ###  ###   #####   ###    ### ",
    "    ###      ##  ##    ##    #######   ###      ###    ### ",
    "    ###   #  ##  ##    ## ## ###      ###    #  ###   ###  ",
    "   ########   #####     ###   ######  ######## #########   ",
    "                 ##                                        ",
    "             ### ##                                        ",
    "              ####                                         ",
}

-- interpolate from a -> b given t in [0, 1)
local function lerp(a, b, t)
    if t < 0 then
        return a
    elseif t > 1 then
        return b
    end
    return a + t * (b - a)
end

-- The color ramp for the waving banner is quite a bit of math, so pre-compute it.
-- We linearly interpolate 100 steps between two HSV colors (interpolating in RGB
-- space usually looks bad).
local function make_color_ramp(primary_hue)
    local ramp = {}

    -- The default color is a pleasing blue
    local color_a = { primary_hue, .73, 1 }

    -- white
    local color_b = { primary_hue, 0, 1 }

    for x = 0, 100 do
        local t = x / 100
        local h = lerp(color_a[1], color_b[1], t)
        local s = lerp(color_a[2], color_b[2], t)
        local l = lerp(color_a[3], color_b[3], t)
        local r, g, b = Color.hsv_to_rgb(h, s, l)
        table.insert(ramp, { r, g, b })
    end
    return ramp
end


-- Convert our ASCII banner into a list of (x, y) pairs
local function make_cells(ascii_art)
    local p = {}
    for row, s in ipairs(ascii_art) do
        for col = 1, #s do
            local c = s:sub(col, col)
            if c == '#' then
                table.insert(p, { x = col, y = row })
            end
        end
    end
    return p
end

-- A rectangle with a little bevel is so much more pleasing than just a rectangle
-- We're drawing a square with the corners cut out by `bevel` pixels. Would be easier
-- to draw as two rects but we don't want the overdraw because they'll blend during
-- the fade-in.
local function draw_cell(x, y, size, bevel)
    lyte.draw_rect(x + bevel, y, size - bevel * 2, bevel)
    lyte.draw_rect(x, y + bevel, size, size - bevel * 2)
    lyte.draw_rect(x + bevel, y + size - bevel, size - bevel * 2, bevel)
end

-- The banner responds to the mouse, but we only want it to do something while the mouse
-- is moving. This tracks movement and computes a smooth "mouse influence" function so
-- that there's not a big jarring reaction when the mouse starts/stops moving.
local function MouseWatcher()
    return {
        last_x = 0,
        last_y = 0,
        stationary_time = 0,
        move_time = 0,
        influence = 0,
        tick = function(self, dt, mouse_x, mouse_y)
            if mouse_x ~= self.last_x or mouse_y ~= self.last_y then
                self:mouse_moved(dt)
            else
                self:mouse_stationary(dt)
            end
            self.last_x = mouse_x
            self.last_y = mouse_y
        end,
        mouse_moved = function(self, dt)
            self.move_time = self.move_time + dt
            self.stationary_time = 0
            -- influence increases linearly
            self.influence = math.min(1, self.influence + dt * 3)
        end,
        mouse_stationary = function(self, dt)
            self.stationary_time = self.stationary_time + dt
            self.move_time = 0
            if self.stationary_time > 1 then
                -- ...and decays exponentially
                self.influence = self.influence * (.1 ^ dt)
            end
        end
    }
end


local function Banner(params, delay)
    return {
        hue = 218,
        cells = make_cells(BANNER),
        color_ramp = make_color_ramp(218),
        params = params,
        delay = delay,
        mouse_watcher = MouseWatcher(),
        t = 0,
        tick = function(self, dt)
            -- recompute our color ramp when needed
            if self.params.hue ~= self.hue then
                self.hue = self.params.hue
                self.color_ramp = make_color_ramp(self.hue)
            end

            self.t = self.t + dt
            self.mouse_watcher:tick(dt, lyte.get_mouse_x(), lyte.get_mouse_y())

            -- Compute the size of the banner cells based on the screen resoultion. We
            -- also apply a transform to center it on the screen
            local width = lyte.get_window_width()
            local height = lyte.get_window_height()
            local cell_size = width / self.params.banner_cell_fraction
            local banner_height = #BANNER * cell_size
            local banner_width = #(BANNER[1]) * cell_size
            local offset_y = (height - banner_height) / 2
            local offset_x = (width - banner_width) / 2
            local mouse_x = lyte.get_mouse_x() - offset_x
            local mouse_y = lyte.get_mouse_y() - offset_y

            lyte.push_matrix()
            lyte.translate(offset_x, offset_y)
            local alpha = lerp(0, 1, (self.t - delay) / 6)
            local influence = self.mouse_watcher.influence
            local t = self.t * self.params.banner_speed
            for _, b in pairs(self.cells) do
                self:draw_wave(b, t, cell_size, mouse_x, mouse_y, influence, alpha)
            end
            lyte.pop_matrix()
        end,
        draw_wave = function(self, b, t, cell_size, mx, my, mouse_influence, alpha)
            -- Each cell is offset by a cosine wave
            local wave = math.cos(t + b.x * self.params.banner_wave_x + (b.y * self.params.banner_wave_y))
            local x = b.x * cell_size
            local y = b.y * cell_size + wave * self.params.banner_wave_magnitude * cell_size

            -- The mouse repels cells: We compute the distance from the pointer to the cell,
            -- and then apply a diminishing force based on distance and how recently the mouse
            -- has moved. We don't let the computed distance fall below a given value because
            -- it then gets pretty chaoitic.
            local dist = math.sqrt((x - mx) ^ 2 + (y - my) ^ 2)
            dist = math.max(dist, self.params.banner_min_dist * cell_size)
            local force_scale = self.params.banner_force_scale * cell_size
            local force = (force_scale / (dist * 2 + 1))
            local vec_x = (x - mx) * force * mouse_influence
            local vec_y = (y - my) * force * mouse_influence

            -- we also compute a color based on the same cosine wave
            local c = (wave + 1) / 2
            local index = math.floor(c * 99)
            local color = self.color_ramp[index + 1]

            lyte.set_color(color[1], color[2], color[3], alpha)
            local size = cell_size * self.params.banner_cell_scale
            draw_cell(x + vec_x, y + vec_y, size, self.params.banner_cell_bevel * size)
        end

    }
end

return Banner
