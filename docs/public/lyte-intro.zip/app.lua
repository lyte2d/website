local Slider = require("slider")
local FPSCounter = require("fps")
local Metaballs = require("metaballs")
local ScrollText = require("scroll")
local Banner = require("banner")
local Ship = require("ship")

-- There are a bunch of arbitrary parameters that are nice to collect in one
-- place for fast iteration. This is kind of a big list of globals -- most of
-- the systems get this table and can inspect it to do their thing.
--
-- A lot of the sizes are in fractions of the screen width or some other relative
-- measure. It makes things annoyingly abstract, but makes us somewhat resolution
-- independent.
local Param = {
    banner_speed = 2.0,           -- how fast the banner waves
    banner_min_dist = 3,          -- how close we let the mouse get to banner cells
    banner_force_scale = 9.5,     -- how does the force on cells scale with distance?
    banner_wave_magnitude = .825, -- how much does the banner wave?
    banner_cell_fraction = 75,    -- how many cells per line?
    banner_cell_bevel = .085,     -- how big is the bevel on cells, in cell-size units?
    banner_wave_x = .125,         -- banner x coord's impact on frequency coefficient
    banner_wave_y = .23,          -- banner y coord's impact on frequency coefficient
    banner_cell_scale = .85,      -- how large the cells render, regardless of spacing
    blobbiness = .2,              -- how much the blobs mix together,
    hue = 218,                    -- our global accent color
    zoom_scale = .2,              -- how exaggerated our final zoom range is
    roto_scale = .05,             -- how exaggerated our final rotation range is
    ship_scale = .03,             -- size of the ship as a fraction of screen width
    ship_speed = .2,              -- speed of the ship
    ship_exhaust_rate = 200,      -- number of particles / sec while thrusting
    ship_type = 1,                -- what kind of ship are we flying
}

-- It's extremely nice to be able to interactively modify the parameters above.
-- These are little debug controls that let us do so. The numbers are allowed
-- ranges for the respective parameter.
local sliders = {
    Slider.new(Param, "banner_speed", .1, 5),
    Slider.new(Param, "banner_min_dist", 0, 20),
    Slider.new(Param, "banner_force_scale", .1, 50),
    Slider.new(Param, "banner_wave_magnitude", 0, 2.5),
    Slider.new(Param, "banner_cell_bevel", 0, .25),
    Slider.new(Param, "banner_wave_x", .1, 1),
    Slider.new(Param, "banner_wave_y", .1, 1),
    Slider.new(Param, "banner_cell_scale", .1, 2),
    Slider.new(Param, "blobbiness", 0.01, .6),
    Slider.new(Param, "hue", 0, 359),
    Slider.new(Param, "zoom_scale", 0, .75),
    Slider.new(Param, "roto_scale", 0, 1),
    Slider.new(Param, "ship_scale", .01, .15),
    Slider.new(Param, "ship_speed", .01, .3),
    Slider.new(Param, "ship_exhaust_rate", 1, 300),
    Slider.new(Param, "ship_type", 1, 2)
}


local Delay = 9
local Music = lyte.load_music("assets/jupiter-girl.ogg")
local debug_visible = false
local Counter = FPSCounter()
local TheBanner = Banner(Param, Delay)
local TheMetaballs = Metaballs(Param)
local TheScroll = ScrollText(Param, Delay + 6)
local TheShip = Ship(Param, -50, 200)

-- has the music ever played?
local ever_played = false
lyte.play_music(Music)

local function display_click_me(width, height)
    lyte.cls(0, 0, 0, 1)
    local text = "Click to start"
    local x = width / 2 - lyte.get_text_width(text) / 2
    local y = height / 2 - lyte.get_text_height(text) / 2
    lyte.draw_text(text, x, y)
    if height > width then
        text = "Best on desktop / laptop"
        x = width / 2 - lyte.get_text_width(text) / 2
        y = height / 2 - lyte.get_text_height(text) / 2 + 30
        lyte.draw_text(text, x, y)
    end
end

-- interpolate from a -> b given t in [0, 1)
local function lerp(a, b, t)
    if t < 0 then
        return a
    elseif t > 1 then
        return b
    end
    return a + t * (b - a)
end


local RotoZoom = function(params)
    return {
        t = 0,
        accum = 0,
        params = params,
        tick = function(self, dt, inner)
            self.t = self.t + dt
            self.accum = self.accum + math.cos(self.t * .75) / 100

            local w = lyte.get_window_width()
            local h = lyte.get_window_height()

            -- we want the rotozoom to "fade in": zoom and scale are computed parametrically
            -- and aren't going to be at zero when t=0.
            local influence = math.min(self.t * .2, 1)

            lyte.push_matrix()

            -- This looks like a mess (probably because it is), but at the core we're just
            -- summing a bunch of sine waves and applying scaling factors that look good.
            local scale = (1.1 + math.sin(self.t * .5) * self.params.zoom_scale)
            local eased_scale = lerp(1.0, scale, influence)
            lyte.scale_at(eased_scale, eased_scale, w / 2, h / 2)

            local rot = self.accum * math.cos(self.t * .125) * self.params.roto_scale
            local eased_rotation = lerp(0.0, rot, influence)
            lyte.rotate_at(eased_rotation, w / 2, h / 2)

            inner()
            lyte.pop_matrix()
        end
    }
end

local TheZoom = RotoZoom(Param)


-- Deal with playing / pausing the music automatically: this is a little annoying because
-- we can't detect loss of focus yet and instead do it by observing a high dt.
-- (https://github.com/lyte2d/lyte2d/pull/87). We *also* need to wait for an input event
-- if we're in a web browser, because it'll be blocked otherwise :(
local function handle_music(dt, width, height)
    if dt > .2 then
        -- must have lost focus
        lyte.pause_music(Music)
        return false
    else
        lyte.resume_music(Music)
    end
    if Music.length_played ~= 0 then
        -- yay, looks like the music is playing
        ever_played = true
    end
    -- if the music isn't playing yet then we must be in a browser -- ask for a click
    -- to enable the AudioContext
    if not ever_played then
        display_click_me(width, height)
        return false
    end
    if lyte.is_mouse_pressed("mb1") and not ever_played then
        lyte.play_music(Music)
    end
    return true
end

function lyte.tick(dt, width, height)
    local playing = handle_music(dt, width, height)
    if not playing then
        return
    end
    -- pan the music based on the mouse coord
    local relative_mouse_x = lyte.get_mouse_x() / width
    if relative_mouse_x >= 0 and relative_mouse_x <= 1 then
        lyte.set_music_pan(Music, 1.0 - relative_mouse_x)
    end

    TheMetaballs:tick(dt)
    TheShip:tick(dt)
    TheScroll:tick(dt)

    -- If the scroll text is done, apply a roto-zoom to the banner.
    if TheScroll:is_done() then
        TheZoom:tick(dt, function() TheBanner:tick(dt) end)
    else
        TheBanner:tick(dt)
    end

    -- The tab key toggles the debug controls and FPS counter
    if lyte.is_key_pressed("tab") then
        debug_visible = not debug_visible
    end
    if debug_visible then
        Slider.render_many(sliders)
        Counter:tick(dt)
    end
end
