-- Simple FPS counter; averages frame counts over 30 frames and keeps track
-- of the "worst" frame time.

local function FPSCounter()
    return {
        count = 30,
        sum = 0,
        average = 0,
        worst_dt = 0,
        tick = function(self, dt)
            self.worst_dt = math.max(self.worst_dt, dt)
            self.count = self.count - 1
            self.sum = self.sum + dt
            if self.count == 0 then
                self.average = 30 / self.sum
                self.sum = 0
                self.count = 30
            end
            lyte.set_color(1, 1, 1, 1)
            local worst_frame = tostring(math.floor(1 / self.worst_dt))
            local s = tostring(math.floor(self.average)) .. " FPS (worst: " .. worst_frame .. ")"
            lyte.draw_text(s, 0, 0)
            if lyte.is_key_pressed("space") then
                self.worst_dt = .001
            end
        end
    }
end

return FPSCounter
