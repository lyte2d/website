-- Dirt simple particle system. Particles have color and a velocity that decays over time.
-- Max count is hardcoded, and it's even just a simple ring-buffer to find a spot for the
-- new stuff.

function Particles()
    return {
        -- it's a little bit annoying but we do a big struct-of-arrays to avoid allocating
        -- hundreds of tiny tables (prooooobably doesn't actually matter though if I'm honest).
        x = {},
        y = {},
        vx = {},
        vy = {},
        age = {},
        r = {},
        g = {},
        b = {},
        a = {},
        max_age = {},
        max_count = 300,
        next = 1,
        spawn = function(self, x, y, vx, vy, r, g, b, a, life)
            local i = self.next
            self.x[i], self.y[i] = x, y
            self.vx[i], self.vy[i] = vx, vy
            self.r[i], self.g[i], self.b[i], self.a[i] = r, g, b, a
            self.age[i] = 0
            self.max_age[i] = life

            self.next = (self.next % self.max_count) + 1
        end,
        tick = function(self, dt)
            local drag = 2.0
            local exp_drag = math.exp(-drag * dt)

            for i = 1, #self.x do
                if self.age[i] < self.max_age[i] then
                    self.x[i] = self.x[i] + self.vx[i] * dt
                    self.y[i] = self.y[i] + self.vy[i] * dt

                    self.vx[i] = self.vx[i] * exp_drag
                    self.vy[i] = self.vy[i] * exp_drag

                    self.age[i] = self.age[i] + dt
                end
            end
            self:draw()
        end,
        draw = function(self)
            for i = 1, #self.x do
                if self.age[i] < self.max_age[i] then
                    local a = self.a[i] * (1 - (self.age[i]) / self.max_age[i])
                    lyte.set_color(self.r[i], self.g[i], self.b[i], a)
                    lyte.draw_rect(self.x[i], self.y[i], 3, 3)
                end
            end
        end
    }
end

return Particles
