-- A dumb little space ship that you can control. Just felt like there had to be something
-- interactive (we call it a game engine after all).

local Particles = require("particles")

local function all(list, pred)
    for _, i in pairs(list) do
        if not pred(i) then
            return false
        end
    end
    return true
end

local exhaust_colors = {
    { 0x9e, 0x28, 0x35 },
    { 0xf7, 0x76, 0x22 },
    { 0xfe, 0xe7, 0x61 },
}


local function Ship(params, x, y)
    return {
        x = x,
        y = y,
        t = 0,
        images = { lyte.load_image("assets/ship.png"), lyte.load_image("assets/pizza.png") },
        angle = 0,
        speed = 0,
        thrust = nil,
        exhaust = Particles(),
        params = params,
        ever_input = false, -- has the user ever controlled the craft?
        particle_deficit = 0,
        key_to_angle = {
            { { "up" },            math.pi * 6 / 4 },
            { { "down" },          math.pi * 2 / 4 },
            { { "left" },          math.pi * 4 / 4 },
            { { "right" },         0 },
            { { "up", "right" },   math.pi * 7 / 4 },
            { { "up", "left" },    math.pi * 5 / 4 },
            { { "down", "right" }, math.pi * 1 / 4 },
            { { "down", "left" },  math.pi * 3 / 4 },
        },
        -- check the keyboard and gamepad for input, return (target_angle, is_thrusting) for
        -- our craft.
        handle_input = function(self)
            local target_angle = self.angle
            local thrusting = false

            -- map arrows, wasd, and dpad to the various directions
            local input = {
                up = lyte.is_key_down("up") or lyte.is_key_down("w") or lyte.is_gamepad_down(0, "dpad_up"),
                down = lyte.is_key_down("down") or lyte.is_key_down("s") or lyte.is_gamepad_down(0, "dpad_down"),
                left = lyte.is_key_down("left") or lyte.is_key_down("a") or lyte.is_gamepad_down(0, "dpad_left"),
                right = lyte.is_key_down("right") or lyte.is_key_down("d") or lyte.is_gamepad_down(0, "dpad_right"),
            }

            for _, keys_angle in ipairs(self.key_to_angle) do
                if all(keys_angle[1], function(k) return input[k] end) then
                    thrusting = true
                    target_angle = keys_angle[2]
                end
            end
            -- check gamepad analog sticks
            local gamepad_x = lyte.get_gamepad_axis(0, "left_x")
            local gamepad_y = lyte.get_gamepad_axis(0, "left_y")
            if math.abs(gamepad_x) < .75 then gamepad_x = 0 end
            if math.abs(gamepad_y) < .75 then gamepad_y = 0 end
            if gamepad_x ~= 0 or gamepad_y ~= 0 then
                target_angle = math.atan2(gamepad_y, gamepad_x)
                thrusting = true
            end

            if thrusting or target_angle ~= self.angle then
                self.ever_input = true
            end
            return target_angle, thrusting
        end,
        tick = function(self, dt)
            self.t = self.t + dt

            -- this is annoying: we want to roughly scale up the image based on the
            -- resolution, but also want to limit ourselves to integer factors because it
            -- looks bad otherwise.
            local desired_width = self.params.ship_scale * lyte.get_window_width()
            local desired_scale = desired_width / self.images[1].width
            local rounded_scale = math.max(1, math.floor(desired_scale + .5))
            local final_size = self.images[1].width * rounded_scale

            local target_angle, thrusting = self:handle_input()

            local target_speed = 0

            -- the ship starts offscreen. If the demo-enjoyer hasn't provided any input by
            -- time t=50, fly it on screen automatically.
            if self.t > 52 and self.t < 54 and not self.ever_input then
                self.y = lyte.get_window_height() * .2
                thrusting = true
            end
            if thrusting then
                target_speed = self.params.ship_speed * lyte.get_window_width()
            end

            if target_speed > 0 then
                self.particle_deficit = self.particle_deficit + self.params.ship_exhaust_rate * dt
            end
            while self.particle_deficit > 1 do
                self.particle_deficit = self.particle_deficit - 1
                local c = math.random(#exhaust_colors)
                local angle = self.angle + (math.random() - .5) * .75
                local speed_scale = 1 + math.random() / 2
                self.exhaust:spawn(
                    self.x + self.images[1].width / 2 + (math.random() - .5) * final_size / 3,
                    self.y + self.images[1].height / 2 + (math.random() - .5) * final_size / 3,
                    -math.cos(angle) * 100 * speed_scale,
                    -math.sin(angle) * 100 * speed_scale,
                    exhaust_colors[c][1] / 255,
                    exhaust_colors[c][2] / 255,
                    exhaust_colors[c][3] / 255,
                    1,
                    1
                )
            end

            -- deal with the annoying wrap-around to decide which way to turn
            local d_angle = target_angle - self.angle
            while d_angle > 3.141 do
                d_angle = d_angle - 3.141 * 2
            end
            while d_angle < -3.141 do
                d_angle = d_angle + 3.141 * 2
            end

            -- angle and speed exponentially approach their target values
            self.angle = self.angle + d_angle * (1 - 2.71828 ^ (-10 * dt))
            self.speed = self.speed + (target_speed - self.speed) * (1 - 2.71828 ^ (-1 * dt))
            self.x = self.x + self.speed * dt * math.cos(self.angle)
            self.y = self.y + self.speed * dt * math.sin(self.angle)
            self.exhaust:tick(dt)
            self:draw(rounded_scale)
        end,
        draw = function(self, scale)
            lyte.set_color(1, 1, 1, 1)
            local index = math.floor(self.params.ship_type + .5)
            local image = self.images[index]
            lyte.draw_image(image, self.x, self.y, self.angle, image.width / 2, image.height / 2, scale,
                scale)
        end
    }
end


return Ship
