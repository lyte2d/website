-- shamelessly ganked from stack overflow
local function hsv_to_rgb(h, s, v)
    local k1 = v * (1 - s)
    local k2 = v - k1
    local r = math.min(math.max(3 * math.abs(((h) / 180) % 2 - 1) - 1, 0), 1)
    local g = math.min(math.max(3 * math.abs(((h - 120) / 180) % 2 - 1) - 1, 0), 1)
    local b = math.min(math.max(3 * math.abs(((h + 120) / 180) % 2 - 1) - 1, 0), 1)
    return k1 + k2 * r, k1 + k2 * g, k1 + k2 * b
end


return {
    hsv_to_rgb = hsv_to_rgb
}
