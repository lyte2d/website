-- The background of our demo is a bunch of metaballs wandering around. This has got to
-- be the classic demo effect with the best bang:buck ratio. The shader below probably
-- looks a little bit inscrutable but I promise the idea is actually extremely straight-
-- forward: https://matiaslavik.wordpress.com/computer-graphics/metaball-rendering/
--
-- To make the empty space a little bit more interesting, I also added a pinwheel effect
-- when the mouse is pressed.

local Color = require("color")

local frag = [[ // glsl
    out vec4 frag_color;

    // Quadratic smooth min taken from https://iquilezles.org/articles/smin/
    float smin(float a, float b, float k) {
        k *= 4.0;
        float h = max(k - abs(a - b), 0.0) / k;
        return min(a, b) - h * h * k * (1.0 / 4.0);
    }

    float sd_circle(vec2 p, float r) {
        return length(p) - r;
    }

    // Our metaballs follow various Lissajous curves. Sounds fancy, but it basically
    // means x and y are functions of two independent sine waves:
    // x(t) = Asin(at + delta), y(t) = Bsin(bt)
    struct Ball {
        float A;
        float B;
        float a;
        float b;
        float d;
        float size;
    };

    void frag_main() {
        // Normalize coordinates (-1 to 1, accounting for aspect ratio)
        vec2 uv = (gl_FragCoord.xy * 2.0 - screen_size.xy) / min(screen_size.y, screen_size.x);
        vec2 mouse = (vec2(mouse_pos.x, screen_size.y - mouse_pos.y) * 2.0 - screen_size.xy) / min(screen_size.y, screen_size.x);

        const int num_balls = 10;
        // Big wad of numbers was generated randomly and stuffed in here
        const Ball balls[num_balls] = Ball[num_balls](
            Ball(1.27, 1.10, 0.70, 0.72, 3.34, 0.11),
            Ball(1.07, 0.87, 0.40, 0.53, 5.95, 0.08),
            Ball(1.17, 1.06, 0.36, 0.61, 4.17, 0.13),
            Ball(1.31, 1.02, 0.63, 0.48, 4.46, 0.14),
            Ball(0.89, 1.37, 0.45, 0.30, 1.27, 0.12),
            Ball(1.07, 1.49, 0.78, 0.51, 0.90, 0.11),
            Ball(1.47, 1.12, 0.30, 0.64, 5.46, 0.12),
            Ball(1.23, 1.16, 0.67, 0.45, 0.38, 0.08),
            Ball(0.96, 1.02, 0.53, 0.55, 5.20, 0.09),
            Ball(1.39, 0.84, 0.33, 0.75, 0.67, 0.12)
        );

        vec2 p;
        float dist;
        float dist_accum;

        p = vec2(
            balls[0].A * sin(time * balls[0].a + balls[0].d),
            balls[0].B * sin(time * balls[0].b)
        );
        dist = sd_circle(uv - p, balls[0].size);
        dist_accum = dist;

    #define HANDLE_BALL(t) \
        p = vec2( \
            balls[t].A * sin(time * balls[t].a + balls[t].d), \
            balls[t].B * sin(time * balls[t].b + balls[t].d * 2.0) \
        ); \
        dist = sd_circle(uv - p, balls[t].size); \
        dist_accum = smin(dist, dist_accum, blobbiness);

        // a loop would be nice, but this crashes some WebGL implementations.
        // So we unroll it by hand, like a barbarian.
        HANDLE_BALL(1);
        HANDLE_BALL(2);
        HANDLE_BALL(3);
        HANDLE_BALL(4);
        HANDLE_BALL(5);
        HANDLE_BALL(6);
        HANDLE_BALL(7);
        HANDLE_BALL(8);
        HANDLE_BALL(9);

        vec3 final = vec3(0.0, 0.0, 0.0);

        // pinwheel effect: center it at the mouse and just draw some radiating stripes.
        float mouse_dist = length(uv - mouse);
        float angle = atan(uv.y - mouse.y, uv.x - mouse.x) + mouse_dist * mouse_dist * sin(time);
        float degrees = angle * 180.0 / 3.14159 + time * 60.0 + 360.0;
        int parity = int(degrees / 18.0) % 2;
        vec3 stripe = color * float(parity) * .6 * mouse_influence;

        final = mix(color, stripe, smoothstep(-0.02, 0.0, dist_accum));
        frag_color = vec4(final, 1.0);
    }
]]

local function make_shader()
    return lyte.new_shader({
        uniforms = {
            screen_size = "vec2",
            time = "float",
            blobbiness = "float",
            color = "vec3",
            mouse_pos = "vec2",
            mouse_influence = "float"
        },
        frag = frag,
        vert = [[ // glsl
            in vec4 coords;
            void vert_main() {
                gl_Position = vec4(coords.xy, 0, 1);
            }
        ]]
    })
end

function Metaballs(params)
    return {
        params = params,
        shader = make_shader(),
        t = 0,

        -- determines how prominent the pinwheels are. 0 means invisible, 1 means
        -- full strength. When the mouse is pressed it quickly saturates at 1.
        mouse_influence = 0,

        tick = function(self, dt)
            self.t = self.t + dt
            local width = lyte.get_window_width()
            local height = lyte.get_window_height()
            self.shader:set("screen_size", { width, height })
            self.shader:set("mouse_pos", { lyte.get_mouse_x(), lyte.get_mouse_y() })

            if lyte.is_mouse_down("mb1") then
                self.mouse_influence = self.mouse_influence + (1 - self.mouse_influence) * (1 - 2.71828 ^ (-3 * dt))
            else
                self.mouse_influence = self.mouse_influence + (0 - self.mouse_influence) * (1 - 2.71828 ^ (-3 * dt))
            end
            self.shader:set("mouse_influence", self.mouse_influence)

            self.shader:set("time", self.t)
            self.shader:set("blobbiness", self.params.blobbiness)
            local r, g, b = Color.hsv_to_rgb(self.params.hue, 1, .2)
            self.shader:set("color", { r, g, b })
            lyte.set_shader(self.shader)
            lyte.draw_rect(0, 0, width, height)
            lyte.reset_shader()
        end
    }
end

return Metaballs
