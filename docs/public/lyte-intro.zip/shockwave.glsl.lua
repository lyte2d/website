{
    uniforms = {
        screen_size = "vec2",
        click_pos = "vec2",
        time = "float",
    },
    frag = [[ //glsl
        in vec2 image_uv;
        out vec4 frag_color;
        void frag_main() {
            vec2 uv = image_uv;
            vec2 click_uv = click_pos / screen_size;

            float aspect = screen_size.x / screen_size.y;
            vec2 dist_vec = uv - click_uv;
            dist_vec.x *= aspect;
            float dist = length(dist_vec);

            // Timing and Shape
            float wave_speed = 0.25;
            float current_radius = time * wave_speed;
            float wave_width = 0.1;

            float pow_dist = pow(dist, 0.5); // Makes the wave feel more organic
            float edge = smoothstep(current_radius, current_radius - 0.01, dist) * smoothstep(current_radius - wave_width, current_radius, dist);

            vec2 offset = normalize(uv - click_uv) * edge * 0.05;

            float highlight = smoothstep(current_radius - 0.005, current_radius, dist) * smoothstep(current_radius + 0.005, current_radius, dist);

            vec3 tint_color = vec3(0.5, 0.8, 1.0);
            float fade = max(0.0, 1.0 - time * 1.0); // Fades out over 1 second

            float r = texture(current_image, uv + offset * 1.1).r;
            float g = texture(current_image, uv + offset).g;
            float b = texture(current_image, uv + offset * 0.9).b;
            vec3 base_color = vec3(r, g, b);


            vec3 final_color = base_color + (highlight * tint_color * fade * 2.0);
            final_color += (edge * tint_color * fade * 0.3);

            frag_color = vec4(final_color, 1.0);
        }
    ]],
    vert = [[ //glsl
        in vec4 coords;
        out vec2 image_uv;
        void vert_main() {
            gl_Position = vec4(coords.xy, 0, 1);
            image_uv = coords.zw;
        }
    ]]
}