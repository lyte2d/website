-- Wouldn't be a demo without some scroll text, would it? Only real "effect" here is an
-- occasional ripple that's computed in a vertex shader.

local Color = require("color")

local function make_shader()
    return lyte.new_shader({
        uniforms = {
            time = "float",
        },
        frag = [[ // glsl
            in vec2 image_uv;
            out vec4 frag_color;

            void frag_main() {
                frag_color = texture(current_image, image_uv) * current_color;
            }
        ]],
        vert = [[ // glsl
            in vec4 coords;
            out vec2 image_uv;

            void vert_main() {
                // the ripple technically lives in the range [-1, 1], but we make it
                // wider so the tails don't start and end abruptly. And we want some dead
                // time between them.
                float peak = fract(time / 7.0) * 5.0 - 2.5;
                float width = 0.25;
                if (abs(coords.x - peak) < width) {
                    float t = abs(coords.x - peak) / (width * 2.0) * 3.141;
                    gl_Position = vec4(coords.x, coords.y + 0.075 * cos(t), 0.0, 1.0);
                } else {
                    gl_Position = vec4(coords.x, coords.y , 0.0, 1.0);
                }
                image_uv = coords.zw;
            }
        ]]
    })
end


local scroll_text = (
    "Lyte2D is a comfy little engine for making 2D games! It has a very small and expressive API. " ..
    "Effortlessly export tiny 1-2MB binaries to Windows, OSX, Linux, and the internets. Features include: " ..
    "2D graphics! (Images, shapes, blending, fonts, vertex shaders, and fragment shaders)    " ..
    "Controllers! (Mouse, keyboard, joystick, and gamepad)   " ..
    "Audio! (Music and sound effects with pitch, volume and pan control. " ..
    "Speaking of audio, this sick music is by John Børge Holen-Tjelta (Arachno) and Lars Tomas Lian (Scrap))              " ..
    "Check it out ==> https://lyte2d.com " ..
    "                     While you're here, press TAB to access the debug interface. "
)


function ScrollText(params, delay)
    local f = lyte.load_font("assets/press-start-2p.ttf", 30)
    lyte.set_font(f)
    local width = lyte.get_text_width(scroll_text)
    lyte.reset_font()
    return {
        shader = make_shader(),
        font = f,
        t = 0,
        delay = delay,
        speed = 110,
        params = params,
        width = width,
        get_scroll_pos = function(self)
            local screen_width = lyte.get_window_width()
            return (screen_width + self.speed * self.delay) - self.t * self.speed
        end,
        is_done = function(self)
            local pos = self:get_scroll_pos()
            return pos + self.width < 0
        end,
        tick = function(self, dt)
            self.t = self.t + dt
            local scroll_pos = self:get_scroll_pos()
            local height = lyte.get_window_height()

            self.shader:set("time", self.t)
            lyte.set_shader(self.shader)
            lyte.set_font(self.font)

            local r, g, b = Color.hsv_to_rgb(self.params.hue + 15, 1, .9)
            lyte.set_color(r, g, b, 1)
            lyte.draw_text(scroll_text, scroll_pos + 5, height - 40 + 5)

            lyte.set_color(1, 1, 1, 1)
            lyte.draw_text(scroll_text, scroll_pos, height - 40)

            lyte.reset_font()
            lyte.reset_shader()
        end
    }
end

return ScrollText
