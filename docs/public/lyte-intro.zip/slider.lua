-- An incredibly simple immediate-mode slider widget. Each slider has a min-max range and
-- a label.

local function new_slider(box, key, min, max)
    return {
        box = box,
        key = key,
        min = min,
        max = max,
        render = function(self, x, y)
            local percent = (self.box[self.key] - self.min) / (self.max - self.min)
            local width = 100
            local height = 10
            local text_vert_offset = 15
            lyte.set_color(1, 1, 1, 1)
            lyte.draw_rect(x, y, width * percent, height)
            lyte.set_color(.3, .3, .3, 1)
            lyte.draw_rect(x + width * percent, y, width - width * percent, height)
            local mx = lyte.get_mouse_x()
            local my = lyte.get_mouse_y()
            if mx >= x and mx <= x + width and my >= y and my <= y + height and lyte.is_mouse_down("mb1") then
                local p = (mx - x) / width
                self.box[self.key] = self.min + (self.max - self.min) * p
            end
            lyte.set_color(1, 1, 1, 1)
            lyte.draw_text(self.key .. ": " .. tostring(self.box[self.key]), x + 105, y - text_vert_offset)
        end,
    }
end


return {
    new = new_slider,
    render_many = function(sliders)
        local line_height = lyte.get_text_height("A") * 1.5
        local x = 10
        local y = 40
        for _, s in ipairs(sliders) do
            s:render(x, y)
            y = y + line_height
        end
    end
}
